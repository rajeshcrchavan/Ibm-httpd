# IBM HTTP Server Archive Install Instructions

## Installation Instructions
  1. Extract the archive containing the IHS runtime files (and this README).
  2. Move the extracted directory to wherever the final install location is desired.
  3. Run `postinstall.sh` or `postinstall.bat` from the server root, passing no arguments.
  4. **Windows Only (OPTIONAL):** Create a service using `httpd.exe -k install -n service-name`

## Applying Maintenance
  1. Obtain a new archive install.
  2. Stop IHS.
  3. **AIX Only:** Run slibclean.
  4. Unpack the new archive install on top of the parent directory of the installation root.
  5. **Windows only:** Run `postinstall.bat` from the server root, passing no arguments.

## Notes
  1. Do not store data in the gsk8 subdirectory.
  2. Do not remove conf/postinst.properties.
  3. Archive maintenance is cumulative only and is a full-replacement.
  4. Java, and by extension ikeyman, are not included.  Use `bin/gskcapicmd` for certificate management.
  5. See `bin/quickssl.sh` or `bin/quickssl.bat` to create a basic self-signed certificate.
