#!/bin/sh

# Changes to this file will not be preserved.

dir=`dirname $0`

# Get absolute install root the hokey portable way
CUR_DIR=`pwd`
IHS_DIR=`dirname ${0}`
cd ${IHS_DIR}
SR=`pwd`
cd ${CUR_DIR}

cd $SR

# Remove any old GSK directories and replace it with the new .gsk8 directory
if [ -d .gsk8 ]; then
    rm -rf gsk8
    mv .gsk8 gsk8
fi

chmod 755 gsk8/bin/* gsk8/private*
(cd gsk8 && ./private_postinstall)

if [ ! -f conf/postinst.properties ]; then
  $SR/bin/postinst -t install -i $SR
  rc=$?
  if [ $rc -ne 0 ]; then
    echo "postinst install failed with rc = $rc"
    rm -f conf/postinst.properties
    exit 1
  fi

  echo "<IfFile plugin/config/webserver1/plugin-cfg.xml>"                    >> conf/httpd.conf
  echo "  LoadModule was_ap24_module plugin/bin/mod_was_ap24_http.so"        >> conf/httpd.conf
  echo "  WebSpherePluginConfig $SR/plugin/config/webserver1/plugin-cfg.xml" >> conf/httpd.conf
  echo "</IfFile>"                                                           >> conf/httpd.conf

  mkdir -p plugin/logs/webserver1
  mkdir -p plugin/config/webserver1

else
  $SR/bin/postinst -t update -i "$SR"
  rc=$?
  if [ $rc -ne 0 ]; then
    echo "postinst update failed with rc = $rc"
    exit 1
  fi
  # These were inadvertently added in 9.0.0.4 with missing dependencies. Removed in 9.0.0.11
  if [ ! -f "$SR/conf/.keep-PH06010" ]; then
    rm -f "$SR/modules/mod_session.so" "$SR/modules/mod_session_cookie.so" "$SR/modules/mod_session_dbd.so"
  fi
fi


